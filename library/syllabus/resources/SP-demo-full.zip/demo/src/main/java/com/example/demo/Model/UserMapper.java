package com.example.demo.Model;

import com.example.demo.Entity.User;
import org.mindrot.jbcrypt.BCrypt;
import com.example.demo.Model.CreateUserRequest;

public class UserMapper {

    public static UserModel toUserModel(User user) {
        var userModel = new UserModel();
        userModel.setId(user.getId());
        userModel.setAvatar(user.getAvatar());
        userModel.setEmail(user.getEmail());
        userModel.setName(user.getName());
        userModel.setPhone(user.getPhone());

        return  userModel;
    }

    public static User toUser(CreateUserRequest req) {
        User user = new User();
        user.setName(req.getName());
        user.setEmail(req.getEmail());
        user.setPhone(req.getPhone());

        // Hash password using BCrypt
        String hash = BCrypt.hashpw(req.getPassword(), BCrypt.gensalt(12));
        user.setPassword(hash);

        return user;
    }

    public  static User toUpdateUser(User user, UpdateUserRequest req) {
        user.setName(req.getName());
        user.setEmail(req.getEmail());
        user.setPhone(req.getPhone());

        // Hash password using BCrypt
        String hash = BCrypt.hashpw(req.getPassword(), BCrypt.gensalt(12));
        user.setPassword(hash);

        return user;
    }
}


