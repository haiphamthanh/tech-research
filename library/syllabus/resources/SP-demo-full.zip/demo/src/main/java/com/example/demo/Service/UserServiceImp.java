package com.example.demo.Service;


import com.example.demo.Model.CreateUserRequest;
import com.example.demo.Model.UpdateUserRequest;
import com.example.demo.Model.UserMapper;
import com.example.demo.Model.UserModel;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import com.example.demo.Entity.User;
import com.example.demo.Exception.DuplicateRecordException;
import com.example.demo.Exception.NotFoundException;
import org.mindrot.jbcrypt.BCrypt;

@Component
public class UserServiceImp implements  UserService {

    private static ArrayList<User> users = new ArrayList<User>();

    static {

        users.add(new User(1, "Nguyễn thai ha", "mongmo@gmail.com","0987654321","avatar.img","123"));
        users.add(new User(2, "nguyen thanh hai", "laclac@gmail.com","0123456789","avatar1.img","123"));
        users.add(new User(3, "Phan Thị tho", "abcd@gmail.com","0987564664","avatar3.img","123"));
        users.add(new User(4, "Bành Thị hung", "bdha@gmail.com","0874845455","avatar9.img","123"));

    }

    @Override
    public ArrayList<UserModel> getUserList() {
        var userModels = new ArrayList<UserModel>();

        for(User user : users) {
            userModels.add(UserMapper.toUserModel(user));
        }
        return userModels;
    }

    @Override
    public UserModel getUserById(int id) {
        for (User user: users) {
            if(user.getId() == id) {
                return UserMapper.toUserModel(user);
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        for(User user: users) {
            if (user.getId() == id) {
                users.remove(user);
                return true;
            }
        }

        throw new NotFoundException("No user found");
    }

    @Override
    public UserModel createUser(CreateUserRequest request) {
        // Check email exist
        for (User user : users) {
            if (user.getEmail().equals(request.getEmail())) {
                throw new DuplicateRecordException("Email already exists in the system");
            }
        }

        // Convert CreateUserReq -> User
        User user = UserMapper.toUser(request);
        user.setId(users.size()+1);

        // Insert user
        users.add(user);

        return UserMapper.toUserModel(user);
    }

    @Override
    public UserModel updateUser(UpdateUserRequest request, int id) {

        for (User user : users) {
            if (user.getId() == id) {
                if (!user.getEmail().equals(request.getEmail())) {
                    // Check new email exist
                    for (User tmp : users) {
                        if (tmp.getEmail().equals(request.getEmail())) {
                            throw new DuplicateRecordException("New email already exists in the system");
                        }
                    }
                    user.setEmail(request.getEmail());
                }
                user.setName(request.getName());
                user.setPhone(request.getPhone());
                user.setAvatar(request.getAvatar());
                user.setPassword(BCrypt.hashpw(request.getPassword(), BCrypt.gensalt(12)));
                return UserMapper.toUserModel(user);
            }
        }

        throw new NotFoundException("No user found");
    }

    @Override
    public ArrayList<UserModel> searchUser(String keyword) {
        var userModels = new ArrayList<UserModel>();
        for (User user: users) {
            if(user.getName().contains(keyword)) {
                userModels.add(UserMapper.toUserModel(user));
            }
        }
        return userModels;
    }

}

