package com.example.demo.Service;


import com.example.demo.Model.UserMapper;
import com.example.demo.Model.UserModel;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import com.example.demo.Entity.User;

@Component
public class UserServiceImp implements  UserService {

    private static ArrayList<User> users = new ArrayList<User>();

    static {

        users.add(new User(1, "Nguyễn thai ha", "mongmo@gmail.com","0987654321","avatar.img","123"));
        users.add(new User(2, "nguyen thanh hai", "laclac@gmail.com","0123456789","avatar1.img","123"));
        users.add(new User(3, "Phan Thị tho", "abcd@gmail.com","0987564664","avatar3.img","123"));
        users.add(new User(4, "Bành Thị hung", "bdha@gmail.com","0874845455","avatar9.img","123"));

    }

    @Override
    public ArrayList<UserModel> getUserList() {
        var userModels = new ArrayList<UserModel>();

        for(User user : users) {
            userModels.add(UserMapper.toUserModel(user));
        }
        return userModels;
    }

    @Override
    public UserModel getUserById(int id) {
        for (User user: users) {
            if(user.getId() == id) {
                return UserMapper.toUserModel(user);
            }
        }
        return null;
    }

    @Override
    public ArrayList<UserModel> searchUser(String keyword) {
        var userModels = new ArrayList<UserModel>();
        for (User user: users) {
            if(user.getName().contains(keyword)) {
                userModels.add(UserMapper.toUserModel(user));
            }
        }
        return userModels;
    }

}

