package com.example.demo.Service;

import com.example.demo.Model.UserModel;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public interface UserService {

    public ArrayList<UserModel> getUserList();

    public  UserModel getUserById(int id);

    public  ArrayList<UserModel> searchUser(String keyword);
}
