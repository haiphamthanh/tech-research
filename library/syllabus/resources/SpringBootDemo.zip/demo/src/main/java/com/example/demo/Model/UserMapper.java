package com.example.demo.Model;


import com.example.demo.Entity.User;

public class UserMapper {

    public static UserModel toUserModel(User user) {
        var userModel = new UserModel();
        userModel.setId(user.getId());
        userModel.setAvatar(user.getAvatar());
        userModel.setEmail(user.getEmail());
        userModel.setName(user.getName());
        userModel.setPhone(user.getPhone());

        return  userModel;
    }
}
